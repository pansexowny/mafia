Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 27
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale = 'en'

Config.MafiaStations = {

  Mafia = {

    Blip = {
      Pos     = { x = 0, y = 0, z = 0 },
      Sprite  = 0,
      Display = 0,
      Scale   = 0,
      Colour  = 0,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_BAT',              price = 10 },
      { name = 'WEAPON_SWITCHBLADE',      price = 55 },
      { name = 'WEAPON_FLAREGUN',         price = 25 },
      { name = 'WEAPON_STUNGUN',          price = 50 },
      { name = 'WEAPON_SNSPISTOL',		  price = 215 },
      { name = 'WEAPON_PISTOL',     	  price = 355 },
      { name = 'WEAPON_REVOLVER',         price = 370 },
      { name = 'WEAPON_HEAVYPISTOL',      price = 500 },
      { name = 'WEAPON_MACHINEPISTOL',    price = 1500 },
      { name = 'WEAPON_MICROSMG',         price = 2500 },
      { name = 'WEAPON_PUMPSHOTGUN',      price = 4000 },
      { name = 'WEAPON_COMPACTRIFLE',     price = 5000 },
      { name = 'WEAPON_ASSAULTRIFLE',     price = 6250 },
      { name = 'WEAPON_MG',				  price = 15000 },
      { name = 'WEAPON_SNIPERRIFLE',      price = 25000 },
      { name = 'WEAPON_HEAVYSNIPER',      price = 55000 },
      { name = 'WEAPON_MOLOTOV',		  price = 500 },
    },

    AuthorizedVehicles = {
      { name = 'enduro',	 label = 'Motocykl Enduro' },
      { name = 'glendale',	 label = 'Auto klasyczne' },
      { name = 'dominator',	 label = 'Muscle car' },
      { name = 'schafter3',  label = 'Auto luksusowe' },
      { name = 'cogcabrio',	 label = 'Auto cabrio' },
      { name = 'carbonizzare', label = 'Auto sportowe' },
      { name = 'sandking',   label = '4X4' },
      { name = 'mesa3',      label = 'Terenówka' },
      { name = 'guardian',   label = 'Guardian' },
      { name = 'burrito3',   label = 'VAN' },
      { name = 'surfer',	 label = 'Ogórek' },
      { name = 'mule2',      label = 'Ciężarówka transportowa' },
      { name = 'phantom',    label = 'TIR' },
      { name = 'trailers',   label = 'Naczepa' },
    },

    Cloakrooms = {
      { x = -1911.57, y = 2073.89, z = 139.45 },
    },

    Armories = {
      { x = 1104.58, y = -3099.48, z = -40.0 },
    },

    Vehicles = {
      {
        Spawner    = { x = -1528.5, y = 79.91, z = 55.8 },
        SpawnPoint = { x = -1524.74, y = 94.81, z = 56.61 },
        Heading    = 224.63,
      }
    },
  
  Helicopters = {
      {
        Spawner    = { x = 20.312, y = 535.667, z = 173.67 },
        SpawnPoint = { x = 3.40, y = 525.56, z = 177.919 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = -1921.49, y = 2048.88, z = 139.77 },
      { x = 1414.22, y = 1119.07, z = 114.14 },
    },

    BossActions = {
      { x = -1535.85, y = 97.84, z = 55.88 }
    },

  },

}
