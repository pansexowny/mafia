Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 27
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale = 'en'

Config.MafiaStations = {

  Mafia = {

    Blip = {
      Pos     = { x = 0, y = 0, z = 0 },
      Sprite  = 0,
      Display = 0,
      Scale   = 0,
      Colour  = 0,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_BAT',              price = 10 },
      { name = 'WEAPON_SWITCHBLADE',      price = 55 },
      { name = 'WEAPON_FLAREGUN',         price = 25 },
      { name = 'WEAPON_STUNGUN',          price = 50 },
      { name = 'WEAPON_SNSPISTOL',		  price = 215 },
      { name = 'WEAPON_PISTOL',     	  price = 355 },
      { name = 'WEAPON_REVOLVER',         price = 370 },
      { name = 'WEAPON_MACHINEPISTOL',    price = 1500 },
      { name = 'WEAPON_MICROSMG',         price = 2500 },
      { name = 'WEAPON_PUMPSHOTGUN',      price = 4000 },
      { name = 'WEAPON_COMPACTRIFLE',     price = 5000 },
      { name = 'WEAPON_ASSAULTRIFLE',     price = 6250 },
      { name = 'WEAPON_MG',				  price = 15000 },
      { name = 'WEAPON_SNIPERRIFLE',      price = 25000 },
      { name = 'WEAPON_HEAVYSNIPER',      price = 55000 },
      { name = 'WEAPON_MOLOTOV',		  price = 500 },
    },

    AuthorizedVehicles = {
      { name = 'enduro',	 label = 'Motocykl Enduro' },
      { name = 'glendale',	 label = 'Auto klasyczne' },
      { name = 'dominator',	 label = 'Muscle car' },
      { name = 'schafter3',  label = 'Auto luksusowe' },
      { name = 'cogcabrio',	 label = 'Auto cabrio' },
      { name = 'carbonizzare', label = 'Auto sportowe' },
      { name = 'sandking',   label = '4X4' },
      { name = 'mesa',       label = 'Terenówka' },
      { name = 'guardian',   label = 'Guardian' },
      { name = 'burrito3',   label = 'VAN' },
      { name = 'surfer',	 label = 'Ogórek' },
      { name = 'mule3',      label = 'Ciężarówka transportowa' },
    },

    Cloakrooms = {
      { x = -1911.57, y = 2073.89, z = 139.45 },
    },

    Armories = {
      { x = -1937.61, y = 2051.38, z = 139.93 },
    },

    Vehicles = {
      {
        Spawner    = { x = -1925.27, y = 2048.16, z = 139.88 },
        SpawnPoint = { x = -1920.4, y = 2044.43, z = 140.70 },
        Heading    = 255.2,
      }
    },
  
  Helicopters = {
      {
        Spawner    = { x = 20.312, y = 535.667, z = 173.67 },
        SpawnPoint = { x = 3.40, y = 525.56, z = 177.919 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = -1921.49, y = 2048.88, z = 139.77 },
      { x = 21.35, y = 543.3, z = 175.15 },
    },

    BossActions = {
      { x = -1892.42, y = 2079.95, z = 140.08 }
    },

  },

}
